package com.weatherstation.temperature;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

import static java.lang.System.out;
/**
 * Servlet implementation class temperature
 */
public class temperature extends HttpServlet {
	static String Interupt = "0";
	static String InLoop = "0";
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public temperature() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter writer = response.getWriter();
		writer.println("Loading Leds....... ");
		
		if(request.getParameter("value")!=null){
			LedController led = new LedController();
			int value = Integer.parseInt(request.getParameter("value"));
			led.setTemperatureRange(value - 20);
			writer.println(led.temperatureRange);
			led.setGpioChannel(led.temperatureRange);
			led.setLed();
			//writer.println(led.GpioChannels);
			
			
		}
		
		
		/*int value = 0;
		if(request.getParameter("value")!= null){
			value = Integer.parseInt(request.getParameter("value"));
			LedController ledcontroller = new LedController();
			if(temperature.InLoop == "0"){
				writer.println("Starting PWM ....");
				ledcontroller.init();
				ledcontroller.pwm(value);
				writer.println("1st Interupt");
			}
			else{
				Interupt = "1";
				//for interupt external
				if(value < 99){
					int seconds = 0;
					while(Interupt == "1" && seconds < 10){
						//hold on until the Interupt changes to 0 or 10 secs
						try{
							java.lang.Thread.sleep(1000);
						}catch(Exception e){
							e.printStackTrace();
						}
						seconds ++;
					}
					if(Interupt == "0"){
						writer.println("Starting new thread .... ");
						ledcontroller.pwm(value);
						writer.println("Ending the thread .");
					}
					else{
						writer.println("Could not be Interupted !!!!");
					}	
				}
				else{
					writer.println("Externally Interupted !!!!");
				}
			}
		}*/
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
