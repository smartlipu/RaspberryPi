package com.weatherstation.temperature;

import java.io.FileWriter;
import java.io.File;
import java.io.PrintWriter;
import java.util.Arrays;

/**
*	@author	Danish shrestha
**/
public class LedController{
	static final String GPIO_OUT = "out";
	static final String GPIO_ON = "1";
	static final String GPIO_OFF = "0";
	
	
	static String[] GpioChannels;
	String[] GpioChannelDefault = {"23","17","24","18","25","27","4","22"};
	int temperatureRange = 0;
	
	/**
	 * @param args the command line arguments.
	 */
	//@SuppressWarnings("UserSpecificCatch")
	public static void main(String[] args){
		
	}
	
	/**
	 * @param range
	 * Function to set the GPIO Channel.
	 */
	public void setGpioChannel(int range){
		//GpioChannels. = null;
		//Arrays.fill(GpioChannels, null);
		GpioChannels = new String[range+1];
		for(int i = 0;i<=range;i++){
			GpioChannels[i] = GpioChannelDefault[i]; 
		}
	}	
	/**
	 * Set the temperature Range
	 * @param temperature
	 */
	public void setTemperatureRange(int temperature){
		
		int range = 0;
		//-10 below
		if(temperature < -10){
			range = 0;
		}
		else if(temperature <= 0 && temperature > -10){
			range = 1;
		}
		else if(temperature <= 10 && temperature >0){
			range = 2;
		}
		else if(temperature <=20 && temperature >10){
			range = 3;
		}
		else if(temperature <= 30 && temperature > 20){
			range = 4;
		}
		else if(temperature <= 40 && temperature >30){
			range = 5;
		}
		else if(temperature <=50 && temperature >40){
			range = 6;
		}
		else{
			range = 7;
		}
		
		temperatureRange = range;
	}
	
	
	public void setLed(){
		init();
		gpioWrite(GPIO_OFF, GpioChannelDefault);
		gpioWrite(GPIO_ON,GpioChannels);
	}
	
	
	public void init(){
		try{
			/*** Init GPIO port for output ***/
			// Open file handles to GPIO port unexport and export controls
			
			//Loop through all ports if more than 1
			for(String gpioChannel : GpioChannelDefault){
				FileWriter unexportFile = new FileWriter("/sys/class/gpio/unexport");
				FileWriter exportFile = new FileWriter("/sys/class/gpio/export");
				//System.out.println(gpioChannel);
				// Reset the port, if needed
				File exportFileCheck = new File("/sys/class/gpio/gpio" + gpioChannel);
				if(exportFileCheck.exists()){
					unexportFile.write(gpioChannel);
					unexportFile.flush();
					unexportFile.close();
				}
				//set the port for use
				exportFile.write(gpioChannel);
				exportFile.flush();
				exportFile.close();
				//Open file handle to port input/output control
				FileWriter directionFile = new FileWriter("/sys/class/gpio/gpio" + gpioChannel + "/direction");
				//Set port for output
				directionFile.write(GPIO_OUT);
				directionFile.flush();
				directionFile.close();
			}
		}catch (Exception exception){
			exception.printStackTrace();
		}
	}
	
	/**
	 * @param value
	 */
	public void pwm(int value){
		temperature.InLoop = "1";
		try{
			while(temperature.Interupt != "1"){
				gpioWrite(GPIO_ON,GpioChannels);
				java.lang.Thread.sleep(0,value*10000);
				gpioWrite(GPIO_OFF,GpioChannels);
				java.lang.Thread.sleep(0,800000);	
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		temperature.Interupt = "0";
	}

	public void gpioWrite(String Write,String[] channels){
		try{
			for(String gpioChannel : channels){
				//Set up a GPIO port as a command channel
				FileWriter commandChannel = new FileWriter("/sys/class/gpio/gpio" + gpioChannel + "/value");
				//HIGH: set the GPIO port ON
				commandChannel.write(Write);
				commandChannel.flush();
				commandChannel.close();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
}