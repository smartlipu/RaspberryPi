package com.weatherstation.temperature;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.weatherstation.temperature.TempHumValue;


/**
 * Servlet implementation class livedata
 */
public class livedata extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public livedata() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//get the temperature / humidity value from the fhem server.
		TempHumValue temp= new TempHumValue();
		String json = temp.getValue();
		
		//set the led according to the temperature value we got.
		LedController led = new LedController();
		led.setTemperatureRange(Integer.parseInt(temp.temperatureinC));
		led.setGpioChannel(led.temperatureRange);
		led.setLed();
		
		
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		out.print(json);
		out.flush();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
